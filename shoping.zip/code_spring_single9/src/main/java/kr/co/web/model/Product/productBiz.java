package kr.co.web.model.Product;

import java.util.List;

public interface productBiz {
	
	public List<productDto> selectList();


}
