use test;

create table t_board (
	bn_idx int   primary key,   		-- 글번호
	bn_ismem char(1) default 'n',   	-- 회원여부
	bn_pwd varchar(20),   				-- 비밀번호
	ai_idx varchar(20) not null,  	 	-- 작성자
	bn_title varchar(100) not null,  	-- 제목
	bn_content text not null,   		-- 내용
	bn_reply int default 0,   			-- 댓글 수 
	bn_read int default 0,   			-- 조회수
	bn_date datetime default now()   	-- 작성일
);