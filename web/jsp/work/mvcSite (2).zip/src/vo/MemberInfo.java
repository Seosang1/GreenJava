package vo;

public class MemberInfo {
// �Ѹ��� ȸ�� ������ �����ϱ� ���� Ŭ����
	private String mi_id, mi_pwd, mi_name, mi_birth, mi_gender, mi_phone;
	private String mi_email, mi_issns, mi_ismail, mi_rebank, mi_account;
	private String mi_recommend, mi_date, mi_isactive, mi_lastlogin;
	private String ma_zip, ma_addr1, ma_addr2;
	private int mi_point, ma_idx;

	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getMi_pwd() {
		return mi_pwd;
	}
	public void setMi_pwd(String mi_pwd) {
		this.mi_pwd = mi_pwd;
	}
	public String getMi_name() {
		return mi_name;
	}
	public void setMi_name(String mi_name) {
		this.mi_name = mi_name;
	}
	public String getMi_birth() {
		return mi_birth;
	}
	public void setMi_birth(String mi_birth) {
		this.mi_birth = mi_birth;
	}
	public String getMi_gender() {
		return mi_gender;
	}
	public void setMi_gender(String mi_gender) {
		this.mi_gender = mi_gender;
	}
	public String getMi_phone() {
		return mi_phone;
	}
	public void setMi_phone(String mi_phone) {
		this.mi_phone = mi_phone;
	}
	public String getMi_email() {
		return mi_email;
	}
	public void setMi_email(String mi_email) {
		this.mi_email = mi_email;
	}
	public String getMi_issns() {
		return mi_issns;
	}
	public void setMi_issns(String mi_issns) {
		this.mi_issns = mi_issns;
	}
	public String getMi_ismail() {
		return mi_ismail;
	}
	public void setMi_ismail(String mi_ismail) {
		this.mi_ismail = mi_ismail;
	}
	public String getMi_rebank() {
		return mi_rebank;
	}
	public void setMi_rebank(String mi_rebank) {
		this.mi_rebank = mi_rebank;
	}
	public String getMi_account() {
		return mi_account;
	}
	public void setMi_account(String mi_account) {
		this.mi_account = mi_account;
	}
	public String getMi_recommend() {
		return mi_recommend;
	}
	public void setMi_recommend(String mi_recommend) {
		this.mi_recommend = mi_recommend;
	}
	public String getMi_date() {
		return mi_date;
	}
	public void setMi_date(String mi_date) {
		this.mi_date = mi_date;
	}
	public String getMi_isactive() {
		return mi_isactive;
	}
	public void setMi_isactive(String mi_isactive) {
		this.mi_isactive = mi_isactive;
	}
	public String getMi_lastlogin() {
		return mi_lastlogin;
	}
	public void setMi_lastlogin(String mi_lastlogin) {
		this.mi_lastlogin = mi_lastlogin;
	}
	public int getMi_point() {
		return mi_point;
	}
	public void setMi_point(int mi_point) {
		this.mi_point = mi_point;
	}
	public String getMa_zip() {
		return ma_zip;
	}
	public void setMa_zip(String ma_zip) {
		this.ma_zip = ma_zip;
	}
	public String getMa_addr1() {
		return ma_addr1;
	}
	public void setMa_addr1(String ma_addr1) {
		this.ma_addr1 = ma_addr1;
	}
	public String getMa_addr2() {
		return ma_addr2;
	}
	public void setMa_addr2(String ma_addr2) {
		this.ma_addr2 = ma_addr2;
	}
	public int getMa_idx() {
		return ma_idx;
	}
	public void setMa_idx(int ma_idx) {
		this.ma_idx = ma_idx;
	}
}
